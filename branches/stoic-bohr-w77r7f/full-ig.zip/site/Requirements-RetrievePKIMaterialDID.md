# Retrieve PKI material as DID - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve PKI material as DID**

## Requirements: Retrieve PKI material as DID (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/Requirements/RetrievePKIMaterialDID | *Version*:1.7.3 |
| Active as of 2026-10-14 | *Computable Name*:Retrieve Public Keys as DID |

 
Retrieve PKI material from a distribution point as DID 

* Publisher: Contact Email
  * No publisher has been registered.: No contact email has been registered.
* Publisher: Jurisdiction
  * No publisher has been registered.: 
* Publisher: Statements
  * No publisher has been registered.: 
* Publisher: Derived from
  * No publisher has been registered.: This requirement is not derived from another requriement.
* Publisher: Derivatives
  * No publisher has been registered.: This requirement has the following derivatives:
* Publisher: Participating Actors
  * No publisher has been registered.: 



## Resource Content

```json
{
  "resourceType" : "Requirements",
  "id" : "RetrievePKIMaterialDID",
  "meta" : {
    "profile" : ["http://smart.who.int/base/StructureDefinition/SGRequirements"]
  },
  "extension" : [{
    "url" : "http://smart.who.int/base/StructureDefinition/Satisfies",
    "valueReference" : {
      "reference" : "Requirements/RetrievePKIMaterial"
    }
  }],
  "url" : "http://smart.who.int/trust/Requirements/RetrievePKIMaterialDID",
  "version" : "1.7.3",
  "name" : "Retrieve Public Keys as DID",
  "title" : "Retrieve PKI material as DID",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-14T15:50:31+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Retrieve PKI material from a distribution point as DID",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "actor" : ["http://smart.who.int/trust/ActorDefinition/TrustNetworkParticipant",
  "http://smart.who.int/trust/ActorDefinition/TrustNetworkAnchor"]
}

```
