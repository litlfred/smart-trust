# GDHCNParticipantDID-AND-SCA - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-AND-SCA**

## Endpoint: GDHCNParticipantDID-AND-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Andorra Trustlist (DID v2) - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:AND:SCA resolvable at https://tng-cdn.who.int/v2/trustlist/-/AND/SCA/did.json

**managingOrganization**: [Organization Andorra](Organization-GDHCNParticipant-AND.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:AND:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-AND-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Andorra Trustlist (DID v2) - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:AND:SCA\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/AND/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-AND"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:AND:SCA"
}

```
