# GDHCNParticipantDID-XXI-DEV-DSC - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXI-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXI-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: California Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXI:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXI/DSC/did.json

**managingOrganization**: [Organization California](Organization-GDHCNParticipant-XXI-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXI:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXI-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "California Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXI:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXI/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXI-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXI:DSC"
}

```
