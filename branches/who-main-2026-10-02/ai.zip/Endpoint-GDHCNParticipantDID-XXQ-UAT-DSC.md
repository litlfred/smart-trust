# GDHCNParticipantDID-XXQ-UAT-DSC - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXQ-UAT-DSC**

## Endpoint: GDHCNParticipantDID-XXQ-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Test Locality Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXQ:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXQ/DSC/did.json

**managingOrganization**: [Organization Test Locality](Organization-GDHCNParticipant-XXQ-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXQ:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXQ-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Test Locality Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXQ:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXQ/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXQ-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXQ:DSC"
}

```
