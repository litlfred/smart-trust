# GDHCNParticipantDID-BRA-DEV-SCA - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BRA-DEV-SCA**

## Endpoint: GDHCNParticipantDID-BRA-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Brazil Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BRA/SCA/did.json

**managingOrganization**: [Organization Brazil](Organization-GDHCNParticipant-BRA-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BRA-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Brazil Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BRA/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BRA-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA"
}

```
