# GDHCNParticipantDID-OMN-DEV-DSC - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-OMN-DEV-DSC**

## Endpoint: GDHCNParticipantDID-OMN-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Oman Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:OMN:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/OMN/DSC/did.json

**managingOrganization**: [Organization Oman](Organization-GDHCNParticipant-OMN-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:OMN:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-OMN-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Oman Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:OMN:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/OMN/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-OMN-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:OMN:DSC"
}

```
