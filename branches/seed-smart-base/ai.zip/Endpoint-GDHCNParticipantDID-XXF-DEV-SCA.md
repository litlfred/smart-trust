# GDHCNParticipantDID-XXF-DEV-SCA - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXF-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXF-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Test Locality XF Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXF:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXF/SCA/did.json

**managingOrganization**: [Organization Test Locality XF](Organization-GDHCNParticipant-XXF-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXF:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXF-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Test Locality XF Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXF:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXF/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXF-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXF:SCA"
}

```
