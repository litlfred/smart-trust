# GDHCNParticipantDID-AND-UAT-DSC - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-AND-UAT-DSC**

## Endpoint: GDHCNParticipantDID-AND-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Andorra Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/AND/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC |
| Connection Type: |  |
| Managed By: | [Andorra (Government)](Organization-GDHCNParticipant-AND-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-AND-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Andorra Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/AND/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-AND-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC"
}

```
