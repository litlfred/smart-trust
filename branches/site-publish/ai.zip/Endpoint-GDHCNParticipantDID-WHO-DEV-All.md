# GDHCNParticipantDID-WHO-DEV-All - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-WHO-DEV-All**

## Endpoint: GDHCNParticipantDID-WHO-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

DEV Participant WHO Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:WHO resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/WHO/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:WHO

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:WHO |
| Connection Type: |  |
| Managed By: | [DEV Participant WHO (Government)](Organization-GDHCNParticipant-WHO-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-WHO-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant WHO Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:WHO\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/WHO/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-WHO-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:WHO"
}

```
