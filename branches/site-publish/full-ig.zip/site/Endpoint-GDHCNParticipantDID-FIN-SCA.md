# GDHCNParticipantDID-FIN-SCA - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-FIN-SCA**

## Endpoint: GDHCNParticipantDID-FIN-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Finland Trustlist (DID v2) - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:FIN:SCA resolvable at https://tng-cdn.who.int/v2/trustlist/-/FIN/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:FIN:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:FIN:SCA |
| Connection Type: |  |
| Managed By: | [Finland (Government)](Organization-GDHCNParticipant-FIN.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-FIN-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Finland Trustlist (DID v2) - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:FIN:SCA\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/FIN/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-FIN"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:FIN:SCA"
}

```
