# GDHCNParticipantDID-URY-UAT-SCA - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-URY-UAT-SCA**

## Endpoint: GDHCNParticipantDID-URY-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Uruguay Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:URY:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/URY/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:URY:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:URY:SCA |
| Connection Type: |  |
| Managed By: | [Uruguay (Government)](Organization-GDHCNParticipant-URY-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-URY-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Uruguay Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:URY:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/URY/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-URY-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:URY:SCA"
}

```
