# GDHCNParticipantDID-JAM-DEV-DSC - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-JAM-DEV-DSC**

## Endpoint: GDHCNParticipantDID-JAM-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Jamaica Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:JAM:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/JAM/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:JAM:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:JAM:DSC |
| Connection Type: |  |
| Managed By: | [Jamaica (Government)](Organization-GDHCNParticipant-JAM-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-JAM-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Jamaica Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:JAM:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/JAM/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-JAM-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:JAM:DSC"
}

```
