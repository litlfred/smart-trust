# GDHCNParticipantDID-IDN-UAT-SCA - WHO SMART Trust v1.7.3

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IDN-UAT-SCA**

## Endpoint: GDHCNParticipantDID-IDN-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Indonesia Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:IDN:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IDN/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:IDN:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:IDN:SCA |
| Connection Type: |  |
| Managed By: | [Indonesia (Government)](Organization-GDHCNParticipant-IDN-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IDN-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Indonesia Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:IDN:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IDN/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IDN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IDN:SCA"
}

```
